<div class="row">
			<div class="col-md-12">
				<center>Copyright &copy <?php echo date ('Y');?> Website MASTER HOTEL, design with <span class="glyphicon glyphicon-heart"></span> by VIOLITA<br/>
				<a href="index.php">Home </a> | 
				<a href="about.php">About Us </a> | 
				<a href="contact.php">Contact Us </a> <br>
				<label class="label label-danger">PERHATIAN:</label>
				Semua informasi di halaman ini memiliki hak cipta, anda tidak diperkenankan untuk menyebarluaskan tanpa seijin pengelola website
				</center>
			</div>
			</div>
	</div><!-- Akhir FOOTER -->
		
<script src="../bootstrap/js/jquery.min.js"></script>
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="../bootstrap/js/dataTables.bootstrap.min.js"></script>
<script src="../bootstrap/js/jquery.dataTables.js"></script>
<script src="../bootstrap/js/scripts.js"></script>

</script>
</body>
</html>