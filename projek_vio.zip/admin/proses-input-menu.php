<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php

include "../koneksi.php";

$Nama=$_POST['Nama'];
$Deskripsi=$_POST['Deskripsi'];
$category=$_POST['Category'];

include "../koneksi.php";

$simpan=$koneksi->query("insert into restoran (Nama,Deskripsi,Category) 
                        values ('$Nama', '$Deskripsi', '$Category')");
if($simpan==true){

    header("location:tampil-menu.php?pesan=inputBerhasil");
} else{
    echo "Error";
}





?>