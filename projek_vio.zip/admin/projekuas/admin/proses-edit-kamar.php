<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php

include "../koneksi.php";

$id_kamar=$_POST['Id_kamar'];
$nomor_kamar=$_POST['Nomor_Kamar'];
$type_kamar=$_POST['Type_Kamar'];
$price_permalam=$_POST['Price_Permalam'];
$status=$_POST['Status'];

$ubah=$koneksi->query("update room set Nomor_Kamar='$nomor_kamar', Type_Kamar='$type_kamar', Price_Permalam='$price_permalam', Status='$status where Id_kamar='$id'");

if($ubah==true){

    header("location:tampil-kamar.php?pesan=editBerhasil");
} else{
    echo "Error";
}

?>