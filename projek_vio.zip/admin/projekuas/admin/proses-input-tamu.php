<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php

$nama_tamu=$_POST['Nama_Tamu'];
$tanggal_lahir=$_POST['Tanggal_Lahir'];
$jenis_kelamin=$_POST['Jenis_Kelamin'];
$alamat=$_POST['alamat'];
$no_telon=$_POST['No_Telpon'];


include "../koneksi.php";

$simpan=$koneksi->query("insert into tamu(Nama_Tamu,Tanggal_Lahir,Jenis_Kelamin,Alamat,No_Telpon) 
                        values ('$nama_tamu', '$tanggal_lahir', '$jenis_kelamin', '$alamat', '$no_telpon')");

if($simpan==true){

    header("location:tampil-tamu.php?pesan=inputBerhasil");
} else{
    echo "Error";
}




?>