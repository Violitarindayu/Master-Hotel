<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php

include "../koneksi.php";

$id=$_POST['Id_Tamu'];
$nama_tamu=$_POST['Nama_Tamu'];
$tanggal_lahir=$_POST['Tanggal_Lahir'];
$jenis_kelamin=$_POST['Jenis_Kelamin'];
$alamat=$_POST['Alamat'];
$no_telpon=$_POST['No_Telpon'];

$ubah=$koneksi->query("update tamu set Nama_Tamu='$nama_tamu', Tanggal_Lahir='$tanggal_lahir', Jenis_Kelamin='$jenis_kelamin', Alamat='$alamat', No_Telpon='$no_telpon' where Id_Tamu='$id'");

if($ubah==true){

    header("location:tampil-tamu.php?pesan=editBerhasil");
} else{
    echo "Error";
}

?>